# Changelog

## 1.0.5
- Update the common chart dependency to `0.1.8`.

## 1.0.4
- Update chart icon to the centralized Stardog open-source asset.

## 1.0.3
- Update the common chart dependency to `0.1.7` for shared Gateway certificate helper behavior.

## 1.0.2
- Support umbrella-level external shared Gateway mode by skipping `Gateway` creation when `global.gateway.createGateway=false`.
- Limit bootstrap TLS secret generation to umbrella-managed shared Gateways.

## 1.0.1
- Maintenance: update maintainer information.

## 1.0.0
- Initial release of the convenience Gateway chart.
