Stardog Helm Chart
==================

This chart installs Stardog, either single node or a cluster that connects to a ZooKeeper ensemble.
The chart pulls the latest version of Stardog from
Docker Hub and does not support rolling upgrades.

Chart Details
-------------

This chart does the following:

- Creates a Stardog Cluster StatefulSet configured with readiness and liveness probes
- Deploys a single node Stardog if the cluster is disabled
- Creates a load balanced service for Stardog
- Optionally specify the anti-affinity for the pods
- Optionally tune resource requests and limits for the pods
- Optionally tune JVM resources for Stardog

Installing
----------

```bash
helm dependency build ./stardog
helm install my-stardog ./stardog
```

Upgrading
---------

> [!WARNING]
> Upgrading from any version earlier than `4.1.0` to `4.1.0` or later requires a StatefulSet migration for clustered installs (`cluster.enabled=true`). This chart version changes `spec.serviceName` (moved to a headless Service) and `spec.podManagementPolicy` (now `Parallel`), both of which Kubernetes treats as immutable on an existing StatefulSet. This applies whether the chart is installed standalone or bundled through the `kube-stardog-stack` umbrella chart (`1.2.0` or later).

```bash
export NAMESPACE=stardog
export RELEASE=my-stardog

kubectl -n "$NAMESPACE" delete sts "$RELEASE" --cascade=orphan

helm -n "$NAMESPACE" upgrade "$RELEASE" ./stardog \
  --reset-then-reuse-values \
  --wait \
  --timeout 15m
```

Orphan-deleting only removes the StatefulSet controller object -- the running pods and PVCs are untouched, and the new StatefulSet adopts the existing pods (matching selector labels) without recreating them. Non-clustered installs (`cluster.enabled=false`) are unaffected and can upgrade normally with `helm upgrade`.

Configuration Parameters
------------------------

| Parameter                                    | Description |
| ---                                          | --- |
| `admin.password`                             | Stardog admin password |
| `additionalStardogProperties`                | Allow adding extra settings to the `stardog.properties` file |
| `backup.*`                                   | Enables the built-in backup CronJob and selects the storage target; see [`BACKUP.md`](BACKUP.md) for the complete matrix |
| `cluster.enabled`                            | Enable Stardog Cluster |
| `cluster.zookeeperService`                   | ZooKeeper connection string (CSV of `host:port` pairs) when using a shared or external ensemble |
| `cluster.zookeeperSessionTolerance.enabled`   | Master switch for the ZooKeeper session tolerance settings below (default `true`); see [ZooKeeper session tolerance](#zookeeper-session-tolerance) |
| `cluster.zookeeperSessionTolerance.rejoinShutdown` | `pack.rejoin.shutdown` override; defaults to `false` on Kubernetes, diverging from the Stardog product default |
| `cluster.zookeeperSessionTolerance.inactiveOnSuspend` | `pack.zookeeper.inactiveOnSuspend` override; unset by default, deferring to the deployed Stardog version's own default |
| `cluster.zookeeperSessionTolerance.disableDnsCaching` | Disable JVM DNS caching for the Stardog server process (default `true`); not a Stardog property |
| `debug.sleepOnFailureSeconds`               | Sleep for N seconds after Stardog exits with a non-zero status (troubleshooting) |
| `debug.javaSsl`                             | Enable verbose Java SSL debug output (`javax.net.debug`) |
| `environmentVariables`                       | Extra environment variables injected into the Stardog container |
| `envFrom`                                    | Additional container `envFrom` entries, such as synced Key Vault Secrets |
| `extraEnv`                                   | Additional container env entries with support for `valueFrom` |
| `extraVolumes`                               | Additional pod volumes, such as Secrets Store CSI volumes |
| `extraVolumeMounts`                          | Additional container volume mounts |
| `secretProviderClass`                        | Optional Secrets Store CSI `SecretProviderClass` rendered by the chart |
| `fullnameOverride`                           | The k8s name for the Stardog deployment |
| `image.password`                             | Docker registry password used to pull the Stardog image |
| `image.pullPolicy`                           | The Docker image `pullPolicy` for Stardog |
| `image.registry`                             | The Docker registry containing the Stardog image |
| `image.repository`                           | The Docker repository containing the Stardog image |
| `image.tag`                                  | The Docker image tag for Stardog (defaults to `latest`; pin a specific version for production) |
| `image.username`                             | Docker registry username used to pull the Stardog image |
| `ingress`                                    | Deprecated Kubernetes ingress exposure (prefer `gateway.*`) |
| `gateway.http.*`                             | Configures the HTTP/HTTPS Gateway listeners and HTTPRoute resources |
| `gateway.http.redirectToLaunchpad.*`         | Optional root-path proxy/redirect (Gateway) to Launchpad (service or external URL) |
| `gateway.tcpBi.*`                            | Enables TCPRoute exposure for the BI/SQL port via the Gateway |
| `headlessService.*`                          | Configures the headless Service used for clustered pod DNS and stable `pack.node.address` values |
| `clusterDomain`                              | Kubernetes DNS cluster domain used when building per-pod Stardog addresses. Defaults to `cluster.local`. |
| `upgrade.approval.targetVersion`             | One-time version-scoped approval for storage upgrades; when it matches `image.tag`, the chart injects `upgrade.automatic=true` |
| `javaArgs`                                   | Java args for Stardog server |
| `log4jConfig.content`                        | New Log4j configuration when overriding the default |
| `log4jConfig.override`                       | Whether to override the default Log4j config |
| `namespaceOverride`                          | The k8s namespace for the Stardog deployment (single node only) |
| `nodeSelector`                               | Node labels to pin Stardog pods to specific node pools |
| `persistence.size`                           | The size of the volume for Stardog home |
| `persistence.storageClass`                   | The storage class to use for Stardog home volumes |
| `podAnnotations`                             | Additional annotations added to the Stardog pod template |
| `podLabels`                                  | Additional labels added to the Stardog pod template |
| `podManagementPolicy`                        | Set the pod startup policy - use `Parallel` (default) or `OrderedReady` |
| `ports.server`                               | The port to expose Stardog server |
| `ports.sql`                                  | The port to expose Stardog BI server |
| `replicaCount`                               | The number of replicas in Stardog Cluster |
| `securityContext.fsGroup`                    | GID for the volume mounts |
| `securityContext.runAsGroup`                 | GID used by the Stardog container to run as non-root |
| `securityContext.runAsUser`                  | UID used by the Stardog container to run as non-root |
| `serverStartArgs`                            | Additional arguments for Stardog server start |
| `serviceAccount.annotations`                 | Extra annotations for the service account when it is created |
| `serviceAccount.create`                      | Whether to create a dedicated service account (default: `true`) |
| `serviceAccount.name`                        | Use an existing service account instead of creating one |
| `tmpDir.local`                               | When `true` (default) the chart provisions an `emptyDir` volume at `tmpDir.path`. Set `false` when the path already resides inside `stardogHome`. |
| `tmpDir.path`                                | Base path used for `java.io.tmpdir`. Defaults to `/var/opt/stardog/tmp-123456789`. |
| `tls.sparql.*`                               | Enable SPARQL TLS and configure keystore generation/cert secrets |
| `tls.bi.*`                                   | Enable BI/SQL TLS (MySQL) and configure keystore generation/cert secrets |
| `tls.truststore.*`                           | Truststore settings for BI TLS and outbound TLS (merged from JVM cacerts + optional CA bundle) |
| `tolerations`                                | Taints the pods tolerate; match with `nodeSelector` to target dedicated pools |
The default values are specified in `values.yaml`.

### Temporary storage (tmpDir)

`tmpDir.path` replaces the legacy string-only `tmpDir` value. When `tmpDir.local=true` (default), the chart provisions an `emptyDir` volume and mounts it at the requested path so the Stardog JVM always has a writable, node-local scratch directory. If you prefer to reuse a directory that already lives on the main PVC (for example `/var/opt/stardog/tmp`), keep the `path` but set `tmpDir.local=false` so the chart reuses the PVC instead of creating an extra volume.

### Node placement controls

`nodeSelector` and `tolerations` are wired through the shared helper so the StatefulSet and its init containers schedule consistently. Use them in tandem to constrain Stardog pods to tainted node pools or dedicated hardware.

### Secret managers and extra runtime injection

Use `secretProviderClass`, `envFrom`, `extraEnv`, `extraVolumes`, and `extraVolumeMounts` to inject secrets or files from external secret systems such as Azure Key Vault CSI without adding chart-specific values for each new variable.

```yaml
stardog:
  secretProviderClass:
    enabled: true
    name: stardog-keyvault
    secretObjects:
      - secretName: stardog-runtime-env
        type: Opaque
        data:
          - objectName: AZURE-CLIENT-ID
            key: AZURE_CLIENT_ID
    parameters:
      keyvaultName: stardog-vault
      tenantId: 00000000-0000-0000-0000-000000000000
      objects: |
        array:
          - |
            objectName: AZURE-CLIENT-ID
            objectType: secret
  envFrom:
    - secretRef:
        name: stardog-runtime-env
  extraEnv:
    - name: AZURE_CLIENT_ID
      valueFrom:
        secretKeyRef:
          name: stardog-runtime-env
          key: AZURE_CLIENT_ID
  extraVolumes:
    - name: keyvault-secrets
      csi:
        driver: secrets-store.csi.k8s.io
        readOnly: true
        volumeAttributes:
          secretProviderClass: stardog-keyvault
  extraVolumeMounts:
    - name: keyvault-secrets
      mountPath: /mnt/secrets-store
      readOnly: true
  serviceAccount:
    annotations:
      azure.workload.identity/client-id: 00000000-0000-0000-0000-000000000000
  podLabels:
    azure.workload.identity/use: "true"
```

### Cluster and ZooKeeper validation

Starting in this release the chart fails fast when `stardog.cluster.enabled=true` but neither a ZooKeeper service (`stardog.cluster.zookeeperService`) nor a shared ZooKeeper (`global.zookeeper.enabled`) is configured. This prevents accidental deployment of clustered pods without quorum services.

For bundled ZooKeeper, Stardog renders `pack.zookeeper.address` as the ZooKeeper ensemble pod DNS list through the ZooKeeper headless Service:

```text
zookeeper-<release>-0.zookeeper-<release>-headless.<namespace>.svc.<clusterDomain>:2181,
zookeeper-<release>-1.zookeeper-<release>-headless.<namespace>.svc.<clusterDomain>:2181,
zookeeper-<release>-2.zookeeper-<release>-headless.<namespace>.svc.<clusterDomain>:2181
```

The generated list uses `global.zookeeper.replicaCount`, defaulting to `3`. If you override `zookeeper.replicaCount` in the umbrella chart, keep `global.zookeeper.replicaCount` in sync. If `stardog.cluster.zookeeperService` is set, the chart uses that explicit value unchanged instead.

When `stardog.cluster.enabled=true`, the StatefulSet uses a headless Service named `<stardog-fullname>-headless` for pod DNS. Each pod appends its own `pack.node.address` at startup using:

```text
<pod-name>.<stardog-fullname>-headless.<namespace>.svc.<clusterDomain>:<ports.server>
```

The normal Stardog Service remains available for clients. The headless Service exists for Stardog cluster members to identify and reach specific pods directly.

Changing an existing clustered StatefulSet from the previous client Service to the headless Service changes `spec.serviceName`, which Kubernetes treats as immutable. Existing clustered installs need a StatefulSet migration, such as delete with `--cascade=orphan` and recreate through Helm, before this change can be applied in place.

### ZooKeeper session tolerance

`cluster.zookeeperSessionTolerance` controls how a clustered node reacts to a transient ZooKeeper session disruption (for example, a ZooKeeper ensemble leader restart). It is rendered into `stardog.properties` only while `cluster.enabled=true`.

| Value | Default | Behavior |
| --- | --- | --- |
| `enabled` | `true` | Master switch for this block. Set `false` to render none of the settings below, even if they are also set. |
| `rejoinShutdown` | `false` | Sets `pack.rejoin.shutdown`. The Stardog product default is `true`, which makes a node deliberately exit its JVM whenever it needs to rejoin the cluster -- a reasonable model when a VM/bare-metal process supervisor restarts it promptly, but a poor fit for Kubernetes: CrashLoopBackOff does not distinguish a deliberate graceful exit from a real crash, so repeated rejoins escalate into exponentially growing pod-restart delays. The chart defaults this to `false` instead, so a rejoin happens in-process with no pod restart. Confirmed via rolling-restart testing. |
| `inactiveOnSuspend` | unset (`""`) | Sets `pack.zookeeper.inactiveOnSuspend`. Left unset by default so the deployed Stardog version's own default (`true` as of this writing) applies without the chart needing to track it. Set explicitly (`true`/`false`) to override. Unlike `rejoinShutdown`, this setting has no Kubernetes-specific downside -- escalating from `SUSPENDED` to `INACTIVE` does not restart the JVM by itself. |
| `disableDnsCaching` | `true` | Not a Stardog property -- injects `-Dsun.net.inetaddr.ttl=0 -Dsun.net.inetaddr.negative.ttl=0` into the Stardog server's JVM args. Without this, the JVM's default DNS-cache TTL can make a ZooKeeper client keep retrying a ZooKeeper ensemble member's stale, pre-restart address instead of noticing that it changed (e.g. after a pod restart). |

None of `rejoinShutdown` or `inactiveOnSuspend` can be set directly in `stardogProperties`/`additionalStardogProperties` -- the chart fails fast with a message pointing at the corresponding `cluster.zookeeperSessionTolerance.*` value instead, so there is a single source of truth.

### Service accounts and custom environment variables

Stardog and its hooks run under the same service account determined by `serviceAccount.create` and `serviceAccount.name`. Populate `environmentVariables` when you need to inject extra JVM flags or platform-specific settings—the chart renders them verbatim into the container spec while still managing the base PATH and Stardog variables on your behalf.

### Version-scoped upgrade approval

For storage upgrades that require `upgrade.automatic=true`, do not set that property directly in `stardogProperties`. Instead, set `upgrade.approval.targetVersion` to the exact `image.tag` you are deploying.

```yaml
image:
  tag: 9.2.1

upgrade:
  approval:
    targetVersion: 9.2.1
```

When the two values match, the chart injects `upgrade.automatic=true` into the generated `stardog.properties`. If `upgrade.approval.targetVersion` is empty or does not match `image.tag`, the chart renders without injecting `upgrade.automatic=true`. This makes the approval a one-off safety valve for the target version, without blocking upgrades that do not need Stardog's automatic data-upgrade flag.

### Gateway API (Traefik) exposure

If your cluster uses the Gateway API with Traefik (or another compatible controller), you can replace the classic ingress resources by enabling the `gateway` block:

```yaml
gateway:
  enabled: true
  http:
    className: traefik
    domain: example.com
    tls:
      enabled: true
      secretName: stardog-gateway-cert
```

When this flag is on the chart renders a Gateway plus the required `HTTPRoute` objects. Set `gateway.http.domain` to the base domain (for example `example.com`) so the chart can generate the SPARQL (`sparql.example.com`) and BI (`bi.example.com`) hostnames. Disable the legacy ingress (`ingress.enabled=false`) and be sure the TLS secret named above exists in the release namespace. If you omit `gateway.http.tls.secretName` while `certIssuer.enabled=true`, the chart automatically reuses the cert-manager secret that ingress relied on (`sparql-<release>-tls` by default).

When the umbrella chart enables `global.gateway.enabled=true`, Stardog automatically switches to shared-Gateway attachment mode. With `global.gateway.createGateway=true`, the umbrella-managed shared `Gateway` is created by the `gateway` subchart and Stardog routes attach to it automatically. With `global.gateway.createGateway=false`, no `Gateway` resource is created by Helm; instead, Stardog derives its HTTPS, HTTP redirect, and BI TCP listener `parentRefs` from `global.gateway.name`, `global.gateway.namespace`, `global.gateway.sparqlSectionName`, `global.gateway.sparqlHttpSectionName`, and `global.gateway.biTcpSectionName`.

ACME issuers auto-configure HTTP-01 solvers for whichever front door (ingress or gateway) you enable. When `gateway.http.redirect.enabled=true` and redirect parentRefs are set, the solver targets those HTTP listener parentRefs so HTTP-01 can complete. Override `certIssuer.acme.solvers` when you prefer a DNS-01 provider or need custom solver settings.

When Gateway TLS is enabled and cert-manager is issuing the certificate, the chart also creates an HTTP listener for the BI hostname (`bi.<domain>`) so the HTTP-01 challenge can attach and validate the BI SAN.

If you still rely on a Launchpad landing page, you can add an exact-match `/` rule to the Gateway route:

```yaml
gateway:
  enabled: true
  http:
    domain: example.com
  redirectToLaunchpad:
    enabled: true
    serviceName: ""   # defaults to launchpad-<release> when global.launchpad.enabled=true
    servicePort: 80
    externalUrl: ""   # alternatively proxy to an external Launchpad URL
    mode: ""          # "redirect" (RequestRedirect), "proxy", or "backend" (301 via redirect backend)
```

With that block turned on, the chart renders an exact-match `/` path for `sparql.<domain>`. In `proxy` mode it forwards to the Launchpad service (or an ExternalName service pointing at the provided URL), while every other path continues to point at the Stardog backend. When the umbrella chart deploys Launchpad alongside Stardog, the redirect auto-enables and defaults to the bundled Launchpad Service name. Set `enabled: false` to opt out, or supply `externalUrl` and the chart will create an `ExternalName` service that points at the provided hostname so the Gateway can still proxy traffic to the remote Launchpad endpoint.

If your Gateway controller does not implement `RequestRedirect` (for example HAProxy Gateway), set `mode: backend` to deploy a tiny redirect backend that returns HTTP 301 responses and still keeps the `sparql.<domain>` hostname for API calls:

```yaml
gateway:
  redirectToLaunchpad:
    enabled: true
    mode: backend
```

Need raw TCP for BI? Enable the TCPRoute listener (auto-on when `bi.enabled=true` unless overridden):

```yaml
gateway:
  enabled: true
  http:
    domain: example.com
  tcpBi:
    enabled: true        # defaults to true when bi.enabled=true
    port: 5806     # Listener port exposed by Traefik/Gateway
    protocol: TCP   # keep TCP for MySQL start-TLS; terminate TLS at Stardog
bi:
  enabled: true      # required so the Service exposes the SQL port
```

Optional: expose BI/SQL via a dedicated Service (separate from the main Service). This is useful when you want a distinct `LoadBalancer`, annotations, or source ranges for SQL traffic:

```yaml
bi:
  enabled: true
  service:
    enabled: true
    type: LoadBalancer
    annotations: {}
    loadBalancerSourceRanges: []
```

When `bi.service.enabled=false`, the SQL port is still exposed on the main Service (and the Gateway TCPRoute still targets it).

When you need SPARQL TLS, enable `tls.sparql.enabled` and point it at the same certificate secret used by the Gateway or cert-manager:

```yaml
tls:
  sparql:
    enabled: true
    required: false
    secretName: stardog-gateway-cert
```

When you need BI TLS (MySQL start-TLS), enable `tls.bi.enabled` and use the same secret unless you need dedicated certs:

```yaml
tls:
  bi:
    enabled: true
    secretName: stardog-gateway-cert
```

The chart converts the TLS secret into a PKCS12 keystore by default. SPARQL TLS writes javax.net.ssl.* settings into the `stardog.properties` file and adds `--enable-ssl` (and `--require-ssl` when `tls.sparql.required=true`). BI TLS adds the javax.net.ssl.* settings to the JVM arguments.

If `tls.sparql.secretName` or `tls.bi.secretName` is omitted, the chart falls back to the Gateway TLS secret (when enabled) or the certIssuer secret.

### Truststore behavior (BI TLS)

When BI TLS is enabled, the chart **automatically enables** a truststore so the server can validate upstream HTTPS/JWKS and other outbound TLS calls. The generated truststore starts from the JVM default `cacerts` and then optionally merges a custom CA bundle.

To add private CA certs (for internal endpoints), mount a secret and let the init container merge it:

```yaml
tls:
  truststore:
    enabled: true            # auto-enabled when tls.bi.enabled=true
    caSecretName: my-ca-bundle
    caSecretKey: ca.crt      # defaults to ca.crt
```

The merged truststore is written to `/var/opt/stardog/keystore/stardog-truststore.p12` (name configurable via `tls.truststore.name`).

This adds a Gateway listener plus a `TCPRoute` that forwards directly to the BI service port (`.Values.ports.sql`). Adjust the listener port/protocol (and optional TLS passthrough settings) to match your controller’s expectations.

> **Ingress deprecation:** The older `ingress.*` block remains for backward compatibility but now emits a warning when enabled and will be removed in a future release.

> **BI limitation:** The legacy ingress path no longer exposes the BI/SQL endpoint. Set `bi.enabled=true` only when using `gateway.*`.

Upgrades
--------

Stardog Cluster supports rolling upgrades for **minor and patch releases** (e.g. `9.0.0` → `9.0.1`). Pin the desired `image.tag`, run `helm upgrade`, and Kubernetes will restart the pods according to the configured StatefulSet `podManagementPolicy`.

Major version upgrades still require a full shutdown. Before jumping from (for example) `8.x` to `9.x`, make sure there are no running transactions and then delete the Stardog pods before redeploying them with the new Stardog version. If there are manual
steps required as part of the upgrade process k8s jobs will need to be used
to run the steps on the Stardog home directories in the PVCs.

See the [Stardog documentation](https://www.stardog.com/docs/#_upgrading_the_cluster)
for instructuions on how to upgrade Stardog Cluster.

Limitations
-----------

The chart does not currently support:
- cache targets
- rolling upgrades across major Stardog versions (minor/patch upgrades are supported as described above)

> **Image pinning:** the default container tag is `latest`, so production deployments should always set `image.tag` to a specific Stardog release to avoid unexpected upgrades.

Troubleshooting
---------------

Basic connectivity checks (profile-style examples):

SPARQL over HTTPS:

```bash
curl -vk https://sparql.profile-01e.sd-testlab.com/admin/healthcheck
```

DNS resolution:

```bash
dig +short sparql.profile-01e.sd-testlab.com
dig +short bi.profile-01e.sd-testlab.com
```

BI port reachability (TCP only):

```bash
nc -vz -G 5 bi.profile-01e.sd-testlab.com 5806
```

BI MySQL protocol with TLS (use a MySQL client):

```bash
HOST=bi.profile-01e.sd-testlab.com
mysql --host="$HOST" --port=5806 --user=admin --password \
  --ssl-mode=REQUIRED -e "status"
```

Port-forward sanity check:

```bash
kubectl -n stardog port-forward svc/stardog-sd-stack 5806:5806
nc -vz -G 5 127.0.0.1 5806
```

If you are using Gateway TCPRoute for BI, confirm Gateway objects exist:

```bash
kubectl get gateway,tcproute,httproute -A
```

Keep the container alive after a crash (for log inspection):

```yaml
debug:
  sleepOnFailureSeconds: 600
```

Enable Java SSL debug logging:

```yaml
debug:
  javaSsl: true
```
